import "@k2oss/k2-broker-core";

metadata = {
  systemName: "com.k2.delimitedconverter",
  displayName: "Delimited list converter Broker",
  description: "Converts delimited list to SMO list output.",
  "configuration": {
    "delimiter": {
        displayName: "Delimiter",
        type: "string",
        value: ";"
    }
  },
};

ondescribe = async function ({ configuration }): Promise<void> {
  postSchema({
    objects: {
      delimitedlistconverter: {
        displayName: "Delimited List Converter",
        description: "Converts delimited list to SMO list",
        properties: {
          id: {
            displayName: "ID",
            type: "number",
          },
          value: {
            displayName: "Value",
            type: "string",
          },
        },
        methods: {
          convert: {
            displayName: "Convert",
            type: "list",
            parameters: {
              pdelimitedlist: {
                displayName: "Delimited List",
                description: "Delimited List Input",
                type: "string",
              },
            },
            requiredParameters: ["delimitedlist"],
            outputs: ["id","value"],
          },
        },
      },
    },
  });
};

onexecute = function ({parameters, configuration}) {
  var delimiter = configuration["delimiter"];
  var delimitedlistString = parameters["pdelimitedlist"];
  var stringArray = (<string>delimitedlistString).split(<string>delimiter);
  var length = stringArray.length;
  let myArray = [];
  
  for(var i=1;i <= length; i++) {
      var row = {id:i, value:stringArray[i-1]};
      myArray.push(row);
  }

      
  postResult(myArray.map(x => {
    return {
        "id": x.id,
        "value": x.value,
    }
}));
}
